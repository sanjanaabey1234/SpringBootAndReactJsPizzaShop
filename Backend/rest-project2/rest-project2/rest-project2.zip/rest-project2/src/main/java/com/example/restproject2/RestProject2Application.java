package com.example.restproject2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestProject2Application.class, args);
	}

}
